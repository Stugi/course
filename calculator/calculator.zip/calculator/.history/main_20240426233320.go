package main

import "fmt"

func main() {
	var number1, number2 float64
	var operation string
	fmt.Println("Enter the first number")
	_, err = scanf("%f", &number1)
	if err != nil {
		p
	}
	println("Enter the second number")
	_, _ = scanf("%f", &number2)
	println("Enter the operation")
	_, _ = scanf("%s", &operation)
	println("Result: ", calculator.Calculate(number1, number2, operation))
}
