package main

import (
	"calc/calc"
	"fmt"
)

func main() {
	var number1, number2 float64
	var operation string
	fmt.Println("Enter the first number")
	_, err := fmt.Scanf("%f", &number1)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("Enter the second number")
	_, err = fmt.Scanf("%f", &number2)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("Enter the operation")
	_, err = fmt.Scanf("%s", &operation)
	if err != nil {
		fmt.Println(err)
	}

	calculator := calc.NewCalculator()
	fmt.Println(calculator.Calculate(number1, number2, operation))
}
