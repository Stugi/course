package calc

type calculator struct {
}

func NewCalculator() calculator {
	return calculator{}
}

func (c *calculator) Calculate(a, b float64, oper string) float64 {
	switch oper {
	case "+":
		return c.add(a, b)
	case "-":
		return c.sub(a, b)
	case "*":
		return c.mul(a, b)
	case "/":
		return c.div(a, b)
	default:
		return 0
	}
}

func (c *calculator) add(a, b float64) float64 {
	return a + b
}

func (c calculator) sub(a, b float64) float64 {
	return a - b
}

func (c calculator) mul(a, b float64) float64 {
	return a * b
}

func (c calculator) div(a, b float64) float64 {
	if b == 0 {
		return 0
	}
	return a / b
}
