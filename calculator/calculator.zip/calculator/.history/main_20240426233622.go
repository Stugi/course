package main

import (
	"calc/calc"
	"fmt"
)

func main() {
	var number1, number2 float64
	var operation string
	fmt.Println("Enter the first number")
	_, err := fmt.Scanf("%f", &number1)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("Enter the second number")
	_, err = fmt.Scanf("%f", &number2)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("Enter the operation")
	_, err = fmt.Scanf("%s", &operation)
	if err != nil {
		fmt.Println(err)
	}
	fmt.Println("The result is", calc.Calculate(number1, number2, operation))
}
